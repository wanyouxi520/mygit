test git file
the file is changed
the file is changed for master branch
the file is changed for bugfix_1